#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>

char board[3][3];
char player1;
char player2;
char computer;
char playAgain;
int playMenu, playMode;
void rematch();

//Show the player the board
void showBoard() 
{
    printf("\n %c | %c | %c ", board[0][0], board[0][1], board[0][2]);
    printf("\n---|---|---\n");
    printf(" %c | %c | %c ", board[1][0], board[1][1], board[1][2]);
    printf("\n---|---|---\n");
    printf(" %c | %c | %c ", board[2][0], board[2][1], board[2][2]);
    printf("\n\n");
}

//Restart the game
void restartGame() 
{
    for (int i = 0; i < 3; i++) 
    {
        for (int b = 0; b < 3;b++)
        {
            board[i][b] = ' ';
        }
    }
}

//Check if the game has ended
char checkWinner() 
{
    //horizontal win
    for (int i = 0; i < 3; i++) 
    {
        if (board[i][0] == board[i][1] && board[i][0] == board[i][2])
        {
            return board[i][0];
        }
    }
    //vertical win
    for (int i = 0; i < 3; i++)
    {
        if (board[0][i] == board[1][i] && board[0][i] == board[2][i])
        {
            return board[0][i];
        }
    }
    //diagonal win
    if (board[0][0] == board[1][1] && board[0][0] == board[2][2])
    {
        return board[0][0];
    }
    if (board[0][2] == board[1][1] && board[0][2] == board[2][0])
    {
        return board[0][2];
    }

    return ' ';
}

//Check if there is a tie
char checkTie()
{
    int notFree = 0;

    for (int i = 0; i < 3; i++)
    {
        for (int b = 0; b < 3; b++)
        {
            if (board[i][b] != ' ')
            {
                notFree++;
            }
        }
    }

    if (notFree == 9)
    {
        return 'Tie!';
    }

    return ' ';
}

//Player 1's turn
playerOneMove() 
{
    int x, y;
    showBoard();

    do
    {
        printf("Enter row (1-3)\n\n");
        scanf_s(" %d", &x);
        x--;

        printf("\n\nEnter column (1-3)\n\n");
        scanf_s(" %d", &y);
        y--;

        if (board[x][y] != ' ')
        {
            printf("Invalid move. Please make a valid move.\n\n");
            showBoard();
        }

        else
        {
            if (player1 == 'X')
            {
                board[x][y] = 'X';
                break;
            }

            if (player1 == 'O')
            {
                board[x][y] = 'O';
                break;
            }
        }
    } while (board[x][y] != ' ');
}

//Computer move
void computerTurn()
{
    int x, y;

    do  
    {
        x = rand() % 3;
        y = rand() % 3;

        if (board[x][y] == ' ') 
        {
            if (player1 == 'X')
            {
                board[x][y] = 'O';
                break;
            }

            if (player1 == 'O')
            {
                board[x][y] = 'X';
                break;
            }
        }
    } while (board[x][y] != ' ');
}

//1 player mode
void onePlayer() 
{
    restartGame();
    int oneMenu = 0;
    char xo;
    char winner = ' ';
    char tie = ' ';
    playMenu = 0;
    playMode = 1;

    while (oneMenu == 0)
    {
        printf("\nPlay as X or O?\n\n");
        scanf_s(" %c", &xo, 1);

        if (xo == 'x' || xo == 'X')
        {
            player1 = 'X';

            while (winner == ' ' && tie == ' ')
            {
                winner = checkWinner();
                tie = checkTie();
                if (winner == ' ' && tie == ' ')
                {
                    playerOneMove();
                    winner = checkWinner();
                    tie = checkTie();
                }

                if (winner == ' ' && tie == ' ') 
                {
                    computerTurn();
                }
            }

            showBoard();

            if (winner != ' ')
            {
                printf("\n%c", winner);
                printf(" wins!\n\n");
            }

            else
            {
                printf("\nTie!\n\n");
            }

            rematch();
        }

        if (xo == 'o' || xo == 'O')
        {
            player1 = 'O';

            while (winner == ' ' && tie == ' ')
            {
                winner = checkWinner();
                tie = checkTie();
                if (winner == ' ' && tie == ' ')
                {
                    computerTurn();
                    winner = checkWinner();
                    tie = checkTie();
                }

                if (winner == ' ' && tie == ' ')
                {
                    playerOneMove();
                }
            }

            showBoard();

            if (winner != ' ')
            {
                printf("\n%c", winner);
                printf(" wins!\n\n");
            }

            else
            {
                printf("\nTie!\n\n");
            }
            
            rematch();
        }

        else
        {
            printf("\nPlease select a valid option.\n\n");
        }
    }
}

//2 player mode
void twoPlayer()
{
    restartGame();
    char winner = ' ';
    char tie = ' ';
    playMenu = 0;
    playMode = 2;

    while (winner == ' ' && tie == ' ')
    {
        winner = checkWinner();
        tie = checkTie();
        if (winner == ' ' && tie == ' ')
        {
            player1 = 'X';
            playerOneMove();
            winner = checkWinner();
            tie = checkTie();
            player1 = 'O';
            if (winner == ' ' && tie == ' ')
            {
                playerOneMove();
            }
        }
    }

    showBoard();

    if (winner != ' ')
    {
        printf("\n%c", winner);
        printf(" wins!\n\n");
    }

    else
    {
        printf("\nTie!\n\n");
    }

    rematch();
}

//Play again menu
void rematch()
{
    while (playMenu == 0)
    {
        printf("Play again? (Y/N):\n\n");
        scanf_s(" %c", &playAgain, 1);

        if (playAgain == 'y' || playAgain == 'Y')
        {
            if (playMode == 1)
            {
                onePlayer();
            }

            if (playMode == 2)
            {
                twoPlayer();
            }
        }

        else if (playAgain == 'n' || playAgain == 'N')
        {
            main();
        }

        else
        {
            printf("\nPlease choose a valid option.\n\n");
        }
    }
}

int main() 
{
    int mainMenu = 0;
    char playerNumber;

    while (mainMenu == 0)
    {
        printf("Main Menu\n\n");
        printf("Choose an option:\n\n");
        printf("1. 1 Player\n2. 2 Players\n3. Exit\n\n");
        scanf_s(" %c", &playerNumber, 1);

        if (playerNumber == '1')
        {
            onePlayer();
        }
        else if (playerNumber == '2')
        {
            twoPlayer();
        }

        else if (playerNumber == '3')
        {
            exit(0);
        }

        else
        {
            printf("\nPlease choose a valid option.\n\n");
        }
    }
}